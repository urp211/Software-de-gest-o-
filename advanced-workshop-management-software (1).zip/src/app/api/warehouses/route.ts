import { NextResponse } from "next/server";
import { db } from "@/db";
import { warehouses } from "@/db/schema";

export async function GET() {
  const data = await db.select().from(warehouses);
  return NextResponse.json({ warehouses: data });
}
