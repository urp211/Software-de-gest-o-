import { NextResponse } from "next/server";
import { seedDb } from "@/db/seed";

export async function GET() {
  await seedDb();
  return NextResponse.json({ success: true });
}
