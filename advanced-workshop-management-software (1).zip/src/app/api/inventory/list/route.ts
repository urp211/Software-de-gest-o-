import { NextResponse } from "next/server";
import { db } from "@/db";
import { parts } from "@/db/schema";
import { eq, gt } from "drizzle-orm";

export async function GET() {
  const data = await db.select().from(parts).where(gt(parts.stock, 0));
  return NextResponse.json({ parts: data });
}
